// Minimal adapter for the existing vanilla-JS prototype.
// Call this from the existing submit handler after reading the textarea value.
async function askRealLegalAssistant(question, language = 'auto') {
  const response = await fetch('http://127.0.0.1:8000/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, language })
  });
  if (!response.ok) throw new Error(`AI service returned ${response.status}`);
  return await response.json();
}

// Example:
// const result = await askRealLegalAssistant(question, 'bn');
// console.log(result.answer, result.citations);
// Render answer as textContent (not innerHTML) and render citation links only
// from result.citations after validating their URLs and display labels.

# AI Lawyer Bangladesh — RAG starter (v0.1)

This is the first backend foundation for the existing `frontend-demo.html`. It is deliberately a development starter, not a production legal service.

## What is included

- FastAPI backend with `/health` and `/api/chat`
- Local Ollama chat model integration
- Multilingual-E5-base embeddings with the required `query:` / `passage:` prefixes
- Qdrant vector retrieval
- JSONL legal-section ingestion script
- MySQL schema for users, laws, sections, chats, citations, cases, documents, lawyers and consultations
- Your original HTML prototype copied as `frontend-demo.html`

## Hardware-aware model choices

For a 16 GB RAM / GTX 1650 4 GB laptop, start with `qwen3:4b` in Ollama. The Ollama library lists this quantized model at about 2.5 GB. It may still run partly or entirely on CPU depending on VRAM availability and context length. Do not load multiple large models simultaneously. If it is too slow, test `qwen3:1.7b`; quality will be lower. The multilingual embedding model may also use RAM/CPU. Test one model at a time.

## 1. Install prerequisites

- Python 3.11 or 3.12
- Ollama for Windows
- Docker Desktop (for Qdrant) OR run Qdrant in local embedded mode later
- MySQL Server (optional for this first RAG milestone; schema is in `sql/schema.sql`)

## 2. Start local AI and vector database

In PowerShell:

```powershell
ollama pull qwen3:4b
ollama serve
```

In a second PowerShell window:

```powershell
docker run -d --name ai-lawyer-qdrant -p 6333:6333 -p 6334:6334 -v ai-lawyer-qdrant:/qdrant/storage qdrant/qdrant
```

Qdrant's local API is at `http://localhost:6333`. Keep it local; the default development container has no authentication.

## 3. Install Python dependencies

```powershell
cd ai-lawyer-bangladesh-starter
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

The first embedding run downloads `intfloat/multilingual-e5-base` from Hugging Face. Allow time and disk space for this download.

## 4. Start the API

```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs` and `http://127.0.0.1:8000/health`.

## 5. Add verified legal sections

Edit `data/legal_sections.example.jsonl` and replace every placeholder with an exact section from an authoritative source. Never ingest placeholder text as law. The expected JSONL fields are:

- `source_id` (stable unique ID)
- `act_title`, `year`, `section_number`, `text`
- `source_url`
- `legal_status`: `in_force`, `historical`, `repealed`, or `awaiting_verification`
- `verification_status`: `verified`, `unverified`, or `needs_review`
- optional `jurisdiction`, `language`, `effective_from`, `effective_to`

Then run:

```powershell
python ingestion/ingest_jsonl.py path\to\your_verified_sections.jsonl
```

For the first tests, ingest only a small set of sections reviewed by a qualified legal professional. Keep exact official text and provenance.

## 6. Test the chat API

Use Swagger at `/docs`, or PowerShell:

```powershell
$body = @{ question = "আমার বাড়িওয়ালা কি নোটিশ ছাড়া আমাকে উচ্ছেদ করতে পারেন?"; language = "bn" } | ConvertTo-Json
Invoke-RestMethod -Uri http://127.0.0.1:8000/api/chat -Method Post -ContentType 'application/json' -Body $body
```

The answer should be considered a prototype output only. The current implementation returns retrieved source metadata alongside the model answer; citation enforcement, calibrated retrieval thresholds, robust output parsing, audit logs, and human review workflows are still required before real users rely on it.

## Security and legal safety — not production-ready

- Do not upload confidential client documents to a public demo.
- Add authentication, authorization, rate limits, encrypted storage, secure backups, audit logs and secrets management before deployment.
- Restrict Qdrant and Ollama to trusted local/private networks.
- The model can still make mistakes. Verify every citation against the official legal text and current amendments.
- A lawyer must review legal content and generated legal documents.
- Do not claim that an answer is verified solely because retrieval returned a result.

## Next milestones

1. Verify the local environment and model response.
2. Build the official-law ingestion pipeline (HTML/PDF extraction, OCR, metadata, versioning and review queue).
3. Improve retrieval with hybrid keyword + vector search and a Bengali/English test set.
4. Enforce citation IDs and abstention when sources are weak or conflicting.
5. Connect the existing assistant UI to `/api/chat`.
6. Implement MySQL persistence, authentication and user-specific case access.
7. Add lawyer verification, consultations and document drafting/review.
8. Add automated tests, privacy/security review and lawyer-led evaluation.

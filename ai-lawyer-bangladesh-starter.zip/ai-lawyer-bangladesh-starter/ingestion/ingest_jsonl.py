import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.rag import ensure_collection, index_section


def main():
    parser = argparse.ArgumentParser(description="Index verified legal sections from JSONL into Qdrant")
    parser.add_argument("input", help="Path to a UTF-8 JSONL file")
    args = parser.parse_args()
    path = Path(args.input)
    ensure_collection()
    count = 0
    with path.open("r", encoding="utf-8") as f:
        for line_no, line in enumerate(f, 1):
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            try:
                record = json.loads(line)
                index_section(record)
                count += 1
            except Exception as exc:
                raise SystemExit(f"Error on line {line_no}: {exc}")
    print(f"Indexed {count} legal sections into Qdrant collection.")

if __name__ == "__main__":
    main()

CREATE DATABASE IF NOT EXISTS ai_lawyer_bd CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ai_lawyer_bd;

CREATE TABLE users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(190) UNIQUE,
  phone VARCHAR(30) UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('client','lawyer','admin') NOT NULL DEFAULT 'client',
  preferred_language ENUM('bn','en') NOT NULL DEFAULT 'bn',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE legal_acts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  act_title VARCHAR(300) NOT NULL,
  short_title VARCHAR(150),
  year SMALLINT,
  jurisdiction VARCHAR(80) NOT NULL DEFAULT 'Bangladesh',
  legal_status ENUM('in_force','historical','repealed','awaiting_verification') NOT NULL DEFAULT 'awaiting_verification',
  official_url TEXT,
  last_verified_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_act_title (act_title),
  INDEX idx_act_status (legal_status)
);

CREATE TABLE legal_sections (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  act_id BIGINT UNSIGNED NOT NULL,
  section_number VARCHAR(50) NOT NULL,
  heading VARCHAR(500),
  original_text LONGTEXT NOT NULL,
  bangla_explanation LONGTEXT,
  english_explanation LONGTEXT,
  verification_status ENUM('verified','unverified','needs_review') NOT NULL DEFAULT 'unverified',
  source_url TEXT,
  effective_from DATE NULL,
  effective_to DATE NULL,
  qdrant_point_id CHAR(36) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_section_act FOREIGN KEY (act_id) REFERENCES legal_acts(id),
  UNIQUE KEY uq_act_section (act_id, section_number)
);

CREATE TABLE conversations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id BIGINT UNSIGNED NOT NULL,
  role ENUM('user','assistant','system') NOT NULL,
  content LONGTEXT NOT NULL,
  language ENUM('bn','en','unknown') DEFAULT 'unknown',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
);

CREATE TABLE message_citations (
  message_id BIGINT UNSIGNED NOT NULL,
  legal_section_id BIGINT UNSIGNED NOT NULL,
  retrieval_score DECIMAL(8,6),
  PRIMARY KEY (message_id, legal_section_id),
  FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
  FOREIGN KEY (legal_section_id) REFERENCES legal_sections(id)
);

CREATE TABLE cases (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  case_title VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  description TEXT,
  status ENUM('open','pending','closed') DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE documents (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  case_id BIGINT UNSIGNED NULL,
  document_type VARCHAR(100),
  title VARCHAR(255) NOT NULL,
  storage_path TEXT NOT NULL,
  review_status ENUM('draft','pending_lawyer_review','reviewed') DEFAULT 'draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (case_id) REFERENCES cases(id) ON DELETE SET NULL
);

CREATE TABLE lawyers (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  bar_council_id VARCHAR(100),
  district VARCHAR(100),
  practice_areas JSON,
  languages JSON,
  verification_status ENUM('pending','verified','rejected') DEFAULT 'pending',
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE consultations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_user_id BIGINT UNSIGNED NOT NULL,
  lawyer_id BIGINT UNSIGNED NOT NULL,
  scheduled_at DATETIME NOT NULL,
  mode ENUM('in_person','phone','video') NOT NULL,
  status ENUM('requested','confirmed','cancelled','completed') DEFAULT 'requested',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_user_id) REFERENCES users(id),
  FOREIGN KEY (lawyer_id) REFERENCES lawyers(id)
);

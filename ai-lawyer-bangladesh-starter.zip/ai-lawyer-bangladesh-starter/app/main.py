from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.schemas import ChatRequest, ChatResponse, Citation
from app.rag import ensure_collection, retrieve, generate_answer

@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        ensure_collection()
    except Exception as exc:
        # API can still start; /health reports dependency status.
        app.state.startup_error = str(exc)
    yield

app = FastAPI(title=settings.app_name, version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5500", "http://localhost:5500", "http://127.0.0.1:3000", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"status": "ok", "service": settings.app_name, "startup_error": getattr(app.state, "startup_error", None)}

@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        sources = retrieve(request.question)
        if settings.min_retrieval_score is not None:
            sources = [s for s in sources if s["retrieval_score"] >= settings.min_retrieval_score]
        answer = await generate_answer(request.question, request.language, sources)
        # Return only sources the model actually referenced inline. The model is instructed
        # to cite stable source_id values; never expose arbitrary IDs as valid citations.
        import re
        referenced_ids = set(re.findall(r"\[([A-Za-z0-9._:-]+)\]", answer))
        source_by_id = {s.get("source_id"): s for s in sources}
        invalid_ids = referenced_ids - set(source_by_id)
        for invalid_id in invalid_ids:
            answer = answer.replace(f"[{invalid_id}]", "[citation unavailable]")
        citations = [Citation(
            source_id=s.get("source_id", ""),
            act_title=s.get("act_title", "Unknown Act"),
            year=s.get("year"),
            section_number=s.get("section_number", "Unknown"),
            source_url=s.get("source_url"),
            legal_status=s.get("legal_status", "unknown"),
            verification_status=s.get("verification_status", "unverified"),
            retrieval_score=s["retrieval_score"],
        ) for sid, s in source_by_id.items() if sid in referenced_ids]
        return ChatResponse(
            answer=answer,
            citations=citations,
            retrieval_status="sources_found" if sources else "no_relevant_source",
        )
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"AI service unavailable: {exc}")

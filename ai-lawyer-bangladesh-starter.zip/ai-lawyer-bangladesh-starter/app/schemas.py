from pydantic import BaseModel, Field
from typing import Literal

class ChatRequest(BaseModel):
    question: str = Field(min_length=3, max_length=5000)
    language: Literal["auto", "bn", "en"] = "auto"

class Citation(BaseModel):
    source_id: str
    act_title: str
    year: int | None = None
    section_number: str
    source_url: str | None = None
    legal_status: str
    verification_status: str
    retrieval_score: float

class ChatResponse(BaseModel):
    answer: str
    citations: list[Citation]
    needs_lawyer: bool = True
    disclaimer: str = "This is general legal information, not legal advice. Have a qualified Bangladesh lawyer review decisions and documents."
    retrieval_status: str

from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AI Lawyer Bangladesh API"
    api_host: str = "127.0.0.1"
    api_port: int = 8000
    ollama_base_url: str = "http://127.0.0.1:11434"
    ollama_chat_model: str = "qwen3:4b"
    qdrant_url: str = "http://127.0.0.1:6333"
    qdrant_collection: str = "bd_law_sections"
    embedding_model: str = "intfloat/multilingual-e5-base"
    embedding_dimension: int = 768
    top_k: int = 5
    min_retrieval_score: float | None = None
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()

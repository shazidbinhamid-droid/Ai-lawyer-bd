import json
import uuid
import httpx
from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient, models
from app.config import settings

# E5 models expect these prefixes. Keep the same model and prefixes for indexing and queries.
_embedder = None
_qdrant = None


def embedder():
    global _embedder
    if _embedder is None:
        _embedder = SentenceTransformer(settings.embedding_model)
    return _embedder


def qdrant():
    global _qdrant
    if _qdrant is None:
        _qdrant = QdrantClient(url=settings.qdrant_url)
    return _qdrant


def ensure_collection():
    client = qdrant()
    if not client.collection_exists(settings.qdrant_collection):
        client.create_collection(
            collection_name=settings.qdrant_collection,
            vectors_config=models.VectorParams(
                size=settings.embedding_dimension,
                distance=models.Distance.COSINE,
            ),
        )


def index_section(section: dict):
    required = ["source_id", "act_title", "section_number", "text", "source_url", "legal_status", "verification_status"]
    missing = [k for k in required if k not in section or section[k] in (None, "")]
    if missing:
        raise ValueError(f"Missing required fields: {', '.join(missing)}")
    vector = embedder().encode("passage: " + section["text"], normalize_embeddings=True).tolist()
    payload = {k: v for k, v in section.items() if k != "text"}
    payload["text"] = section["text"]
    qdrant().upsert(
        collection_name=settings.qdrant_collection,
        points=[models.PointStruct(id=str(uuid.uuid5(uuid.NAMESPACE_URL, section["source_id"])), vector=vector, payload=payload)],
    )


def retrieve(question: str):
    query_vector = embedder().encode("query: " + question, normalize_embeddings=True).tolist()
    hits = qdrant().query_points(
        collection_name=settings.qdrant_collection,
        query=query_vector,
        limit=settings.top_k,
        with_payload=True,
    ).points
    results = []
    for hit in hits:
        p = hit.payload or {}
        results.append({**p, "retrieval_score": float(hit.score)})
    return results


async def generate_answer(question: str, language: str, sources: list[dict]):
    if not sources:
        return ("I could not find a relevant legal source in the current knowledge base. "
                "I cannot safely answer this question without verified legal material. "
                "Please consult a qualified Bangladesh lawyer.")

    # Do not present unverified or repealed material as current law. It can still be disclosed as historical/unverified context.
    source_blocks = []
    for i, s in enumerate(sources, 1):
        source_blocks.append(
            f"[SOURCE {i}] source_id={s.get('source_id')}\n"
            f"Act: {s.get('act_title')} ({s.get('year', 'year unknown')})\n"
            f"Section: {s.get('section_number')}\n"
            f"Legal status: {s.get('legal_status')}\n"
            f"Verification status: {s.get('verification_status')}\n"
            f"Source URL: {s.get('source_url')}\n"
            f"Text: {s.get('text')}"
        )

    lang_instruction = {
        "bn": "Answer in clear Bangla.",
        "en": "Answer in clear English.",
        "auto": "Answer in the same language as the user's question (Bangla or English).",
    }[language]
    system = """You are an assistant providing general legal information about Bangladesh, not a lawyer.
Use ONLY the supplied source excerpts for statements about what the law says. Never invent an Act, section, deadline, penalty, court procedure, URL, or legal status.
If the excerpts do not answer the question, say the evidence is insufficient and recommend a qualified lawyer.
Clearly distinguish current/in-force sources from historical, repealed, pending, or unverified sources. Never treat an unverified source as authoritative current law.
Do not claim a source is verified merely because it was retrieved. Do not provide definitive case-specific legal advice.
Cite only source_id values present in the supplied excerpts, using [source_id]. If the user describes arrest, violence, immediate danger, eviction, a court deadline, or another urgent situation, advise prompt help from a qualified lawyer or relevant emergency service.
"""
    user = f"{lang_instruction}\nQuestion: {question}\n\nRetrieved legal excerpts:\n" + "\n\n".join(source_blocks)
    async with httpx.AsyncClient(timeout=180) as client:
        response = await client.post(
            f"{settings.ollama_base_url}/api/chat",
            json={
                "model": settings.ollama_chat_model,
                "stream": False,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "options": {"temperature": 0.1},
            },
        )
        response.raise_for_status()
        return response.json()["message"]["content"]
